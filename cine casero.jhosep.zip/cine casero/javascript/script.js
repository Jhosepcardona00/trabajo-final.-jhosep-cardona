
// Evento de clic en el cuerpo del documento para cerrar la información de la película si se hace clic fuera de la tarjeta
document.body.addEventListener('click', function(event) {
    var cards = document.querySelectorAll('.card');
    cards.forEach(function(card) {
        if (!card.contains(event.target)) {
            card.classList.remove('show-details');
        }
    });
});
function toggleDetails(card) {
    if (card.classList.contains('show-details')) {
        card.classList.remove('show-details');
    } else {
        
        card.classList.add('show-details');
    }
}
